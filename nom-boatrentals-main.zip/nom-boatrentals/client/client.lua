local Framework = exports['nom-lib']:GetLibrary()
local QBCore = exports['qb-core']:GetCoreObject()
local display = false
local boat_names = {}
local boat_prices = {}
local vehicle = {}
local newPrice = {}

function SetDisplay(bool)
    display = bool
    SetNuiFocus(bool, bool)

    SendNUIMessage({
        type = "ui",
        status = bool,
        boat_names = boat_names,
        boat_prices = boat_prices,
    })
end


RegisterNetEvent('nom-boatrentals:enoughMoney')
AddEventHandler('nom-boatrentals:enoughMoney', function()
    if Config.Notify == "nom" then
        exports['nom-notify']:sendNotification("You do not have enough money..", "error", 5000)
    else
        Framework.Notify("You do not have enough money..", "error", 5000)
    end
end)

RegisterNetEvent('nom-boatrentals:removeBoat')
AddEventHandler('nom-boatrentals:removeBoat', function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsUsing(ped)
    if veh ~= 0 then
        Citizen.Wait(1)
        SetEntityAsMissionEntity(veh, true, true)
        DeleteVehicle(veh)
    end
end)

for i = 1, #Config.Boats do
    boat_names[i] = Config.Boats[i].boat_name
    boat_prices[i] = Config.Boats[i].boat_price
end

RegisterNUICallback("close", function()
    SetDisplay(false)
end)

CreateThread(function()
    for _, loc in ipairs(Config.Settings.locations) do
        local hash = loc.pedProps.hash
        local coords = loc.pedProps.location

        -- Request the PED model
        RequestModel(hash)
        while not HasModelLoaded(hash) do
            Wait(10)
        end

        -- Create the PED at the given location
        local rentalPed = CreatePed(0, hash, coords.x, coords.y, coords.z - 1.0, coords.w, false, false)

        -- Check if the PED was created successfully
        if rentalPed and rentalPed ~= 0 then
            TaskStartScenarioInPlace(rentalPed, 'WORLD_HUMAN_CLIPBOARD', true)
            FreezeEntityPosition(rentalPed, true)
            SetEntityInvincible(rentalPed, true)
            SetBlockingOfNonTemporaryEvents(rentalPed, true)

            -- Set up the target
            SetupTarget(rentalPed, loc.vehicleSpawnLocation)
        else
            print("[nom-boatrentals] Failed to spawn PED.")
        end
    end
end)

RegisterNUICallback("rentBoat", function(boatNames)
    SetDisplay(false)

    if not boatNames.spawnedBoatName or boatNames.spawnedBoatName == "" then
        if Config.Notify == "nom" then
            exports['nom-notify']:sendNotification("You must select a boat to rent.", "warning", 5000)
        else
            Framework.Notify("You must select a boat to rent.", "warning", 5000)
        end
        return
    end

    local counter = tonumber(boatNames.counter)
    local boat = boatNames.spawnedBoatName
    local price = tonumber(boatNames.spawnedBoatPrice:sub(1, #boatNames.spawnedBoatPrice - 1))

    TriggerServerEvent("nom-boatrentals:validateRental", boat, price, counter)
end)

RegisterNetEvent("nom-boatrentals:spawnBoat")
AddEventHandler("nom-boatrentals:spawnBoat", function(boat, counter, price)
    local counterMilliseconds = counter * 60000

    RequestModel(boat)
    while not HasModelLoaded(boat) do
        Wait(10)
    end

    local pedCoords = GetEntityCoords(PlayerPedId())
    local nearestLocation = nil
    local minDistance = math.huge

    for _, loc in ipairs(Config.Settings.locations) do
        local spawnCoords = vector3(loc.vehicleSpawnLocation.x, loc.vehicleSpawnLocation.y, loc.vehicleSpawnLocation.z)
        local dist = #(pedCoords - spawnCoords)
        if dist < minDistance then
            minDistance = dist
            nearestLocation = loc.vehicleSpawnLocation
        end
    end

    if nearestLocation then
        local pos = nearestLocation
        local heading = pos.w

        vehicle = CreateVehicle(boat, pos.x, pos.y, pos.z, heading, true, false)
        local playerPed = PlayerPedId()
        SetPedIntoVehicle(playerPed, vehicle, -1)
        SetVehicleFuelLevel(vehicle, 100.0)
        SetModelAsNoLongerNeeded(boat)

        TriggerEvent('vehiclekeys:client:SetOwner', QBCore.Functions.GetPlate(vehicle))

        Citizen.CreateThread(function()
            Wait(counterMilliseconds)
            if DoesEntityExist(vehicle) then
                SetEntityAsMissionEntity(vehicle, true, true)
                DeleteVehicle(vehicle)
                if Config.Notify == "nom" then
                    exports['nom-notify']:sendNotification("Your boat rental has expired.", "warning", 5000)
                else
                    Framework.Notify("Your boat rental has expired.", "warning", 5000)
                end
            end
        end)
    else
        if Config.Notify == "nom" then
            exports['nom-notify']:sendNotification("No valid spawn location found.", "warning", 5000)
        else
            Framework.Notify("No valid spawn location found.", "warning", 5000)
        end
    end
end)

RegisterNUICallback("returnVehicle", function()
    if vehicle then
        Citizen.Wait(1)
        SetEntityAsMissionEntity(vehicle, true, true)
        DeleteVehicle(vehicle)
        TriggerServerEvent("nom-boatrentals:giveMoney")
        SetDisplay(false)
        if Config.Notify == "nom" then
            exports['nom-notify']:sendNotification("You have successfully delivered the vehicle..", "success", 5000)
        else
            Framework.Notify("You have successfully delivered the boat..", "success", 5000)
        end
        vehicle = false
    end
end)

function SetupTarget(rentalPed, spawnLocation)
    local pedCoords = GetEntityCoords(rentalPed) -- Get the actual coordinates of the ped

    if Config.Target == 'textui' then
        lib.points.new({
            coords = pedCoords,
            distance = 2.5,
            onEnter = function()
                lib.showTextUI("Press [E] to rent a boat")
            end,
            onExit = function()
                lib.hideTextUI()
            end,
            nearby = function(self)
                if self.currentDistance < 2.5 and IsControlJustPressed(0, 38) then
                    SetDisplay(true)
                    lib.hideTextUI()
                end
            end,
        })
    else
        local options = {
            options = {
                {
                    name = 'rentBoat',
                    type = "client",
                    action = function()
                        SetDisplay(true)
                    end,
                    icon = "fa-solid fa-ship",
                    label = "Rent a Boat",
                },
            },
            distance = 2.5,
        }
        Framework.target.AddBoxZone('boatrental_target_'..rentalPed, pedCoords, vec3(3, 3, 3), options)
    end
end

if Config.Blips then
    CreateThread(function()
        for _, loc in ipairs(Config.Settings.locations) do
            local pedPosition = loc.pedProps.location
            local blip = AddBlipForCoord(pedPosition.x, pedPosition.y, pedPosition.z)

            SetBlipSprite(blip, 410)
            SetBlipDisplay(blip, 4)
            SetBlipScale(blip, 0.7)
            SetBlipColour(blip, 64)
            SetBlipAsShortRange(blip, true)

            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString("Rent a boat")
            EndTextCommandSetBlipName(blip)
        end
    end)
else
    print("[nom-boatrentals] Your blips has been set to false!")
end
