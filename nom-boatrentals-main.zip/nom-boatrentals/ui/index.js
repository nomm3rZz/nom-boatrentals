$(function () {
    function display(bool) {
        if (bool) {
            $("#container").show();
        } else {
            $("#container").hide();
        }
    }

    display(false);

    window.addEventListener('message', function(event) {
        var func = event.data;
        if (func.type === "ui") {
            for (let i = 0; i < func.boat_names.length; i++) {
                let boatNameElement = document.getElementById("boatname" + (i + 1));
                if (boatNameElement) {
                    boatNameElement.innerHTML = func.boat_names[i];
                } else {
                    //console.error("Element boatname" + (i + 1) + " not found.");
                }
            }

            for (let i = 0; i < func.boat_prices.length; i++) {
                let boatPriceElement = document.getElementById("boatlistprice" + (i + 1));
                if (boatPriceElement) {
                    boatPriceElement.innerHTML = func.boat_prices[i] + "$";
                } else {
                    //console.error("Element boatlistprice" + (i + 1) + " not found.");
                }
            }

            if (func.status == true) {
                display(true);
            } else {
                display(false);
            }
        }
    });

    var spawnedBoatName;
    var spawnedBoatPrice;
    var counter = 0;

    function clear() {
        let centerpic = document.getElementById("centerpic");
        let boatnameCenter = document.getElementById("boatnameCenter");
        let timeText = document.getElementById("timeText");
        
        if (centerpic) centerpic.style.display = "none";
        if (boatnameCenter) boatnameCenter.style.display = "none";
        if (timeText) timeText.innerHTML = "0";
        counter = 0;
    }

    $("#close").click(function () {
        $.post('https://nom-boatrentals/close', JSON.stringify({}));
        clear();
    });

    $("#rentBoat").click(function () {
        $.post('https://nom-boatrentals/rentBoat', JSON.stringify({ spawnedBoatName, counter, spawnedBoatPrice }));
        clear();
    });

    $("#boatlistrentbutton1").click(function() {
        let centerpic = document.getElementById("centerpic");
        let boatnameCenter = document.getElementById("boatnameCenter");
        let boatname1 = document.getElementById("boatname1");
        let boatlistimg1 = document.getElementById("boatlistimg1");

        if (centerpic && boatnameCenter && boatlistimg1) {
            centerpic.src = boatlistimg1.src;
            centerpic.style.display = "flex";
            boatnameCenter.innerHTML = "Boat Name : " + boatname1.innerHTML;
            boatnameCenter.style.display = "flex";
            spawnedBoatName = boatname1.innerHTML;
            spawnedBoatPrice = document.getElementById("boatlistprice1").innerHTML;
        } else {
            //console.error("One or more elements not found in boatlistrentbutton1 click handler.");
        }
    });

    $("#boatlistrentbutton2").click(function() {
        let centerpic = document.getElementById("centerpic");
        let boatnameCenter = document.getElementById("boatnameCenter");
        let boatname2 = document.getElementById("boatname2");
        let boatlistimg2 = document.getElementById("boatlistimg2");

        if (centerpic && boatnameCenter && boatlistimg2) {
            centerpic.src = boatlistimg2.src;
            centerpic.style.display = "flex";
            boatnameCenter.innerHTML = "Boat Name : " + boatname2.innerHTML;
            boatnameCenter.style.display = "flex";
            spawnedBoatName = boatname2.innerHTML;
            spawnedBoatPrice = document.getElementById("boatlistprice2").innerHTML;
        } else {
            //console.error("One or more elements not found in boatlistrentbutton2 click handler.");
        }
    });

    $("#boatlistrentbutton3").click(function() {
        let centerpic = document.getElementById("centerpic");
        let boatnameCenter = document.getElementById("boatnameCenter");
        let boatname3 = document.getElementById("boatname3");
        let boatlistimg3 = document.getElementById("boatlistimg3");

        if (centerpic && boatnameCenter && boatlistimg3) {
            centerpic.src = boatlistimg3.src;
            centerpic.style.display = "flex";
            boatnameCenter.innerHTML = "Boat Name : " + boatname3.innerHTML;
            boatnameCenter.style.display = "flex";
            spawnedBoatName = boatname3.innerHTML;
            spawnedBoatPrice = document.getElementById("boatlistprice3").innerHTML;
        } else {
            //console.error("One or more elements not found in boatlistrentbutton3 click handler.");
        }
    });

    $("#add").click(function() {
        if (counter < 12) {
            counter += 1;
            document.getElementById("timeText").innerHTML = counter;
        }
    });

    $("#sub").click(function() {
        if (counter > 0) {
            counter -= 1;
            document.getElementById("timeText").innerHTML = counter;
        }
    });

    $("#returnVehicle").click(function () {
        $.post('https://nom-boatrentals/returnVehicle', JSON.stringify({}));
        clear();
    });

    $("#leftbutton").click(function() {
        if (counter > 0) {
            counter -= 5;
            document.getElementById("timeText").innerHTML = counter;

            // Change boat prices
            for (let i = 1; i <= 5; i++) {
                let boatPriceElement = document.getElementById("boatlistprice" + i);
                if (boatPriceElement) {
                    boatPriceElement.innerHTML = parseInt(boatPriceElement.innerHTML) - 20 + "$";
                } else {
                    //console.error("Element boatlistprice" + i + " not found.");
                }
            }
        }
    });

    $("#rightbutton").click(function() {
        if (counter < 60) {
            counter += 5;
            document.getElementById("timeText").innerHTML = counter;

            // Change boat prices
            for (let i = 1; i <= 5; i++) {
                let boatPriceElement = document.getElementById("boatlistprice" + i);
                if (boatPriceElement) {
                    boatPriceElement.innerHTML = parseInt(boatPriceElement.innerHTML) + 20 + "$";
                } else {
                    //console.error("Element boatlistprice" + i + " not found.");
                }
            }
        }
    });

    $(".boat").click(function() {
        let centerpic = document.getElementById("centerpic");
        let boatnameCenter = document.getElementById("boatnameCenter");
        let boatname = this.querySelector("h3");
        let boatimg = this.querySelector(".boatlistimg");

        if (centerpic && boatnameCenter && boatname && boatimg) {
            centerpic.src = boatimg.src;
            centerpic.style.display = "flex";
            boatnameCenter.innerHTML = "Boat Name : " + boatname.innerHTML;
            boatnameCenter.style.display = "flex";
            spawnedBoatName = boatname.innerHTML;
            spawnedBoatPrice = this.querySelector(".boatlistprice").innerHTML;
        } else {
            //console.error("One or more elements not found in boat click handler.");
        }
    });
});