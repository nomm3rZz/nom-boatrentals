Config = {}

Config.Notify = "nom" -- Set to "nom" if you are using the nom-notify resource, else set to "false" for your default framework's notifications
Config.Blips = true -- Set to true if you want to display it, otherwise false if you do not want to display it
Config.Target = "target" -- Only use "target" if you use qb-target or ox_target, otherwise set to "textui"
Config.PaymentMethod = "cash" -- Set this to "cash" to deduct cash or use "bank" to deduct the money from the player's account

Config.Settings = {
    locations = {
        [1] = {
            pedProps = {
                hash = 'a_m_y_surfer_01',
                location = vector4(-1605.24, 5256.52, 2.08, 296.22)
            },
            vehicleSpawnLocation = vector4(-1602.69, 5259.29, 0.43, 209.30)
        },
        [2] = {
            pedProps = {
                hash = 'a_m_y_surfer_01',
                location = vector4(-1806.89, -1235.93, 1.60, 329.61)
            },
            vehicleSpawnLocation = vector4(-1798.81, -1228.99, 0.48, 327.13)
        },
        -- add more locations as needed
    }
}

Config.Boats = {
    [1] = {
        ["boat_name"] = "Suntrap",
        ["boat_price"] = 150,
    },
    [2] = {
        ["boat_name"] = "Tropic",
        ["boat_price"] = 300,
    },
    [3] = {
        ["boat_name"] = "Toro",
        ["boat_price"] = 800,
    },
    -- add more vehicles as needed but I would recommend stay on this
}

Config.RefundFee = 100
