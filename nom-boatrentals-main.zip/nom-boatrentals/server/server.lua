local Framework = exports['nom-lib']:GetLibrary()

RegisterServerEvent('nom-boatrentals:giveMoney')
AddEventHandler('nom-boatrentals:giveMoney', function()
    local src = source
    Framework.AddMoney(src, Config.PaymentMethod, Config.RefundFee, 'nom-boatrentals:giveMoney')
end)


RegisterServerEvent('nom-boatrentals:removeMoney')
AddEventHandler('nom-boatrentals:removeMoney', function(boatPrice)
    local src = source
    local playerMoney = Framework.GetMoney(src, Config.PaymentMethod)

    if not playerMoney or tonumber(playerMoney) < tonumber(boatPrice) then
        TriggerClientEvent("nom-boatrentals:enoughMoney", src)
    else
        Framework.RemoveMoney(src, Config.PaymentMethod, tonumber(boatPrice))
        TriggerClientEvent("nom-boatrentals:removeBoat", src)
        if Config.Notify == "nom" then
            TriggerClientEvent('nom-notify:show', src, "You have successfully rented the car!", "success", 5000)
        else
            Framework.Notify(src, "You have successfully rented the boat!", "success", 5000)
        end
    end
end)

RegisterServerEvent("nom-boatrentals:validateRental")
AddEventHandler("nom-boatrentals:validateRental", function(boat, price, counter)
    local src = source
    local playerMoney = Framework.GetMoney(src, Config.PaymentMethod)

    if not playerMoney or tonumber(playerMoney) < tonumber(price) then
        TriggerClientEvent("nom-boatrentals:enoughMoney", src)
    else
        Framework.RemoveMoney(src, Config.PaymentMethod, tonumber(price))
        TriggerClientEvent("nom-boatrentals:spawnBoat", src, boat, counter, price)
        if Config.Notify == "nom" then
            TriggerClientEvent('nom-notify:show', src, "You have successfully rented the car!", "success", 5000)
        else
            Framework.Notify(src, "You have successfully rented the boat!", "success", 5000)
        end
    end
end)